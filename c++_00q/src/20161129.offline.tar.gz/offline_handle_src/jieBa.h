 ///
 /// @file    jieBa.h
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-28 16:50:02
 ///
#ifndef __T_JIEBA_H__ 
#define __T_JIEBA_H__
#include "_THE_INFO_OF_RUN.h"
namespace T520
{
class jieBa
{
public:
	int jieBaVector(string s,vector<string>words);
};
}
#endif

