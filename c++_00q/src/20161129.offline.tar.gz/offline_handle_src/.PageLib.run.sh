g++ Configuration.cc Dirscanner.cc PageLib.cc ReadXMLFile.cc tinyxml2.cc -lboost_regex -std=c++11
