g++ Configuration.cc WebPage.cc jieBa.cc WordQuery.cc -std=c++11
