 ///
 /// @file    PageLibPreprocessor.cc
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-27 18:40:17
 ///
 
#include "_THE_INFO_OF_RUN.h"
#include "PageLibPreprocessor.h"
#include "WebPage.h"
#include "jieBa.h"
namespace T520
{
PageLibPreprocessor::PageLibPreprocessor(Configuration & conf)
:_conf(conf)
,_pageLib()
,_jieba()
,_offsetLib()
,_invertIndexTable()
{
}
void PageLibPreprocessor::doProcess()
{
}
void PageLibPreprocessor::readInfoFromFile()
{
	_conf.
}
void PageLibPreprocessor::cutRedundantPages()
{
}
void PageLibPreprocessor::buildInvertIndexTable()
{
}
void PageLibPreprocessor::storeOnDisk()
{
}
}
