 ///
 /// @file    THE_RUN_OF_INFO.h
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-22 14:33:40
 ///
#ifndef __THE_INFO_OF_RUN_H__
#define _THE_INFO_OF_RUN_H__
#include <stdio.h>
#include <stdlib.h>
#include <set>
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <fstream>
#include <stringstream>
#include <utility>
#include <unordered_map>
#define _THE_INFO_OF_RUN (printf("\t%-30s  %s(%d)\n ",__func__, __FILE__,__LINE__)) 
#define THE_INFO_OF_RUN (printf("\t%-30s  %s(%d)\n ",__func__, __FILE__,__LINE__)) 
using std::ofstream;
using std::ifstream;
using std::istringstream;
using std::ostringstream;
using std::set;
using std::vector;
using std::map;
using std::string;
using std::cout;
using std::cint;
using std::endl;
using std::pair;
using std::unordered_map;
#endif
