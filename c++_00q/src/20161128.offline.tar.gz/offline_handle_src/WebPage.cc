 ///
 /// @file    WebPage.cc
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-27 18:40:46
 ///
 
#include "_THE_INFO_OF_RUN.h"
#include "WebPage.h"
namespace T520
{
	//WebPage::WebPage(string &doc,Configuration &config,WordSegmentation &jieba)
	WebPage::WebPage(string &doc,Configuration &config,jieBa &jieba)
:_doc(doc)
,_conf(config)
,_jieba(jieba)
{
	_THE_INFO_OF_RUN;
}
int WebPage::getDocId()
{
	_THE_INFO_OF_RUN;
	return _docId;
}
string WebPage::getTitle()
{
	_THE_INFO_OF_RUN;
	return _docTitle;
}
string WebPage::summary(const vector<string>&queryWords)
{
	_THE_INFO_OF_RUN;

}
map<string,int>& WebPage::getWordsMap()
{
	return _wordsMap;
}
void WebPage::processDoc(const string &doc)
{
	_THE_INFO_OF_RUN;
	_docId=atoi(getString("<docid>","</docid>",doc).c_str());
	_docUrl=getString("<url>","</url>",doc);
	_docTitle=getString("<title>","</title>",doc);
	_docContent=getString("<content>","</content>",doc);
	_jieba.jieBaVector(_docContent,_eachWords);
}
	std::string WebPage::getString(std::string itemBegin,string itemEnd,string doc)
{
	_THE_INFO_OF_RUN;
	std::string::size_type beginPos;
	std::string::size_type endPos;
	beginPos=doc.find(itemBegin.c_str())+itemBegin.size();
	endPos=doc.find(itemEnd.c_str());
	return doc.substr(beginPos,endPos-beginPos);
}
void clacTopK(vector<string> &wordsVec,int k,set<string>&stopWordList)
{

}

bool operator==(const WebPage&lhs, const WebPage&rhs)
{

}
bool operator<(const WebPage&lhs, const WebPage&rhs)
{

}
}
int main(){}
