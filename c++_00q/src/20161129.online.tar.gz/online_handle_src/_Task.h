 ///
 /// @file    _Tash.h
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-26 09:58:43
 ///
#ifndef __T_TASH_H__ 
#define __T_TASH_H__
#include "_THE_INFO_OF_RUN.h"
#include <functional>
namespace T520
{
typedef std::function<void()> Task;
}
#endif
