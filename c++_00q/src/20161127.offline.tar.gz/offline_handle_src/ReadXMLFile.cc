 ///
 /// @file    readXML.cc
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-10-27 21:04:23
 ///
#include "ReadXMLFile.h" 
namespace T520
{
RssReader::RssReader()
:_rssData()
,_item(NULL)
,_jieBeWordVector()
,_jieBeWordMap()
,_offsetMap()
{};
void RssReader::parseRss(const char * xmlPath)
{
	XMLDocument doc;
	if(doc.LoadFile(xmlPath)!=0)
	{
		cout<<"load xml file failed"<<endl;
		return ;
	}
    XMLElement * channelNode=doc.FirstChildElement("rss")->FirstChildElement("channel");
    if(NULL==channelNode)
        return ;
	_item=channelNode->FirstChildElement("item");
	RssItem tmp_item;
	while(_item!=NULL)
	{
		tmp_item.title=getText("title");
        tmp_item.link=getText("link");
        tmp_item.content=getText("description");
        replaceContent(tmp_item.content);
		jieBaVector(tmp_item.content);
		_rssData.push_back(tmp_item);
		_item=_item->NextSiblingElement();
	}
}
string RssReader::getText(string node)
{
    if(_item!=NULL)
    {
        XMLElement *nodeName=_item->FirstChildElement(node.c_str()); 
        if(nodeName!=NULL)
        {
            return nodeName->GetText();
        }else
        {
            return "";
        }
    }
}
void RssReader::replaceContent(string & content)
{
    boost::regex re1("<.*?>");
    boost::regex re2("&.*?;");
    content=boost::regex_replace(content, re1, string(""));
    content=boost::regex_replace(content, re2, string(""));
}
void RssReader::jieBaVector(string s)
{
	const char* const DICT_PATH = "./dict/jieba.dict.utf8";
	const char* const HMM_PATH = "./dict/hmm_model.utf8";
	const char* const USER_DICT_PATH = "./dict/user.dict.utf8";
	const char* const IDF_PATH = "./dict/idf.utf8";
	const char* const STOP_WORD_PATH = "./dict/stop_words.utf8";
	cppjieba::Jieba jieba(DICT_PATH,
        HMM_PATH,
        USER_DICT_PATH,
        IDF_PATH,
        STOP_WORD_PATH);
	jieba.Cut(s,_jieBeWordVector, true);
	return ;
}
void RssReader::tp_idf_map()
{
	vector<string>::iterator vit;
	for(vit=_jieBeWordVector.begin();vit!=_jieBeWordVector.end();++vit)
	{
		cout<<*vit<<endl;
		auto iter=_jieBeWordMap.find(*vit);
		if(iter!=_jieBeWordMap.end())
			++((*iter).second);
		else
			//_jieBeWordMap[*vit]=1;
			_jieBeWordMap.insert(pair<string,int>(*vit,1));
	}
}
void RssReader::displayMap()
{
	tp_idf_map();
	map<string,unsigned>::iterator iter;
	for(iter=_jieBeWordMap.begin();iter!=_jieBeWordMap.end();++iter)
		cout<<(*iter).first<<"  "<<(*iter).second<<endl;
}
void RssReader::dump(const char * xmlPath)
{
#if 0
	ostringstream sout;
    ofstream fout(xmlPath);
    vector<RssItem>::iterator vit;
    unsigned num=1;
    for(vit=_rssData.begin();vit!=_rssData.end();++vit,++num)
    {
        fout<<"<doc>"<<endl;
        fout<<"  <docid>"<<num<<"</docid>"<<endl;
        fout<<"  <url>"<<(*vit).link<<"</url>"<<endl;
        fout<<"  <title>"<<(*vit).title<<"</title>"<<endl;
        fout<<"  <content>"<<(*vit).content<<"</content>"<<endl;
        fout<<"</doc>"<<endl;
    }
    fout.close();
#endif
#if 1
	ostringstream sout;
    ofstream fout(xmlPath);
    vector<RssItem>::iterator vit;
    unsigned num=0;
    for(vit=_rssData.begin();vit!=_rssData.end();++vit)
    {
        sout<<"<doc>"<<endl;
        sout<<"  <docid>"<<++num<<"</docid>"<<endl;
        sout<<"  <url>"<<(*vit).link<<"</url>"<<endl;
        sout<<"  <title>"<<(*vit).title<<"</title>"<<endl;
        sout<<"  <content>"<<(*vit).content<<"</content>"<<endl;
        sout<<"</doc>"<<endl;
		_offsetMap[num]=sout.str().size();
		fout<<sout.str();
		sout.str("");
    }
    ofstream offsetFile("offset.lib");
	//去除标题中的空格
	map<unsigned,unsigned>::const_iterator it;
	unsigned offsetSize=0;
	for (it = _offsetMap.begin(); it != _offsetMap.end(); ++it)
	{
		offsetFile<< it->first <<" "<< offsetSize << endl; 
		offsetSize+=it->second;
	}
    fout.close();
#endif
}
}
using namespace T520;
int main()
{
	RssReader a;
	a.parseRss("36kr.xml");
	a.dump("36kr.dat");
	a.displayMap();
	return 0;
}
