 ///
 /// @file    THE_RUN_OF_INFO.h
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-22 14:33:40
 ///
#ifndef __THE_INFO_OF_RUN_H__
#define _THE_INFO_OF_RUN_H__
#include <stdio.h>
#define _THE_INFO_OF_RUN (printf("\t%-30s  %s(%d)\n ",__func__, __FILE__,__LINE__)) 
#define THE_INFO_OF_RUN (printf("\t%-30s  %s(%d)\n ",__func__, __FILE__,__LINE__)) 
#endif
