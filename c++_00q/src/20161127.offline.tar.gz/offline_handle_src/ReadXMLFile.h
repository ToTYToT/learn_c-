 ///
 /// @file    ReadXMLFile.h
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-26 16:10:56
 ///
#ifndef __T_READXMLFILE_H__
#define __T_READXMLFILE_H__
//#include "_THE_INFO_OF_RUN.h"
#include <boost/regex.hpp>
#include "cppjieba/Jieba.hpp"
#include "tinyxml2.h"  
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <map>
#include <utility>
#include <unordered_map>
using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::ostringstream;
using std::ofstream;
using std::map;
using std::unordered_map;
using std::pair;
using namespace tinyxml2;  
namespace T520
{
struct RssItem
{
	string title;
	string link;
	string content;
};
struct DocumentFrequency
{
	string titleName;
	map<string,unsigned> wordFrequency;
};
class RssReader
{
public:
	RssReader();
	void parseRss(const char * xmlPath);//解析
	void insertNode(XMLElement* userNode,XMLDocument &doc,const char *name,const char* test);
	void dump(const char*xmlPath);//输出
	void displayMap();
private:
	string getText(string node);
	void replaceContent(string & content);
private:
	void jieBaVector(string s);
	void tp_idf_map();
	unordered_map <string, vector<pair<int, double> > > _InvertIndexTable;
	//string-词语|int-docId|double-w'
	vector<RssItem> _rssData;//string*3
	vector<string> _jieBeWordVector;//
	map<string,unsigned> _jieBeWordMap;//string(word),unsigned(frequency)
	//map<string,unsigned> _offsetMap;//int(docid)unsigned(offsetSize)
	map<unsigned,unsigned> _offsetMap;//unsigned(docid)unsigned(offsetSize)
	XMLElement *_item;
	vector<DocumentFrequency> _documentFrequencyVector;
	map<string,unsigned> _documentFrequencyMap;//存储某个词在所有文章中出现的次数，即包含该词语的文档数量
	unsigned _documentNumSum;
	map<string,unsigned> _inverseDocumentFrequencyMap;//逆文档频率，表示该词对于该篇文章的重要性的一个系数

};  
}
#endif
