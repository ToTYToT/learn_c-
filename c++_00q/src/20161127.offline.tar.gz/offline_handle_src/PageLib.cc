 ///
 /// @file    PageLib.cc
 /// @author  ToTYToT(hongzimeng@foxmail.com)
 /// @date    2016-11-27 13:51:49
 ///
 
#include "_THE_INFO_OF_RUN.h"
#include "PageLib.h"
namespace T520
{
PageLib::PageLib(Configuration &conf,DirScanner &dirscanner,ReadXMLfile &readXML)
:_conf(conf)
,_dirScanner(dirscanner)
,_readXML(readXML)
{
	_THE_INFO_OF_RUN;
}
void PageLib::create()
{
	_THE_INFO_OF_RUN;

}
}
